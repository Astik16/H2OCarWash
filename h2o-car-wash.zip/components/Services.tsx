import React from 'react';
import { motion } from 'framer-motion';
import Section from './ui/Section';
import { CORE_SERVICES, ADDITIONAL_SERVICES } from '../constants';
import { Sparkles, Car, ShieldCheck, Zap } from 'lucide-react';

const Services: React.FC = () => {
  return (
    <Section id="services" className="relative">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">Услуги и <span className="text-brand-500">Цены</span></h2>
        <p className="text-gray-400 max-w-xl mx-auto">
          Прозрачное ценообразование. Никаких скрытых платежей. Вы платите только за результат.
        </p>
      </div>

      {/* Core Services Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
        {CORE_SERVICES.items.map((service, index) => (
          <motion.div 
            key={service.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="glass-panel p-8 rounded-xl relative overflow-hidden group hover:bg-white/5 transition-colors"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
              <Car className="w-24 h-24" />
            </div>
            
            <h3 className="text-2xl font-bold text-white mb-2">{service.name}</h3>
            <div className="text-3xl font-display font-bold text-brand-400 mb-4">{service.price}</div>
            <p className="text-gray-400 text-sm border-t border-white/10 pt-4">
              {service.description}
            </p>
            
            <div className="mt-6">
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-brand-500" />
                  Активная пена
                </li>
                <li className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-brand-500" />
                  Ручная мойка губкой
                </li>
                <li className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-brand-500" />
                  Сушка с продувкой
                </li>
              </ul>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Additional Services */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {ADDITIONAL_SERVICES.map((category, catIndex) => (
          <motion.div 
            key={category.title}
            initial={{ opacity: 0, x: catIndex % 2 === 0 ? -20 : 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-dark-card rounded-xl border border-white/5 p-8"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="p-3 rounded-lg bg-brand-500/10">
                {category.title.includes('кузовом') ? <Car className="w-6 h-6 text-brand-400"/> : 
                 category.title.includes('салоном') ? <Sparkles className="w-6 h-6 text-brand-400"/> :
                 <ShieldCheck className="w-6 h-6 text-brand-400"/>}
              </div>
              <h3 className="text-2xl font-bold text-white">{category.title}</h3>
            </div>

            <div className="space-y-4">
              {category.items.map((item, itemIndex) => (
                <div key={itemIndex} className="flex justify-between items-center py-3 border-b border-white/5 last:border-0 hover:bg-white/5 px-2 rounded-lg transition-colors">
                  <span className="text-gray-300 font-medium">{item.name}</span>
                  <span className="text-brand-400 font-display font-semibold whitespace-nowrap ml-4">{item.price}</span>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default Services;