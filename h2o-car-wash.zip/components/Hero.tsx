import React from 'react';
import { motion } from 'framer-motion';
import { Droplets, ArrowRight } from 'lucide-react';
import Button from './ui/Button';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-dark-bg z-0">
        {/* Animated Gradient Spotlights */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-brand-600/10 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-blue-900/10 rounded-full blur-[120px]" />
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] opacity-20" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 w-full">
        <div className="flex flex-col items-center text-center">
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-6 flex items-center gap-2 px-3 py-1 rounded-full border border-brand-500/30 bg-brand-500/10 backdrop-blur-md"
          >
            <Droplets className="w-4 h-4 text-brand-400" />
            <span className="text-xs font-semibold text-brand-200 uppercase tracking-widest">Premium Detailing Studio</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400 mb-6 leading-tight"
          >
            Идеальная <br/>
            <span className="text-brand-500 relative inline-block">
              Чистота
              <span className="absolute inset-0 text-brand-500 blur-lg opacity-50">Чистота</span>
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl text-gray-400 max-w-2xl mb-10 font-light"
          >
            Детейлинг, который видно с первого взгляда. Премиальный уход за вашим автомобилем в Майском.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
          >
            <a href="#contact" className="w-full sm:w-auto">
              <Button size="lg" className="w-full sm:w-auto gap-2 group">
                Записаться
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </a>
            <a href="#services" className="w-full sm:w-auto">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Узнать цены
              </Button>
            </a>
          </motion.div>
        </div>

        {/* Abstract "Car" Visualization / Decorative Bottom */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.8 }}
          className="mt-20 relative h-[200px] w-full max-w-4xl mx-auto hidden md:block"
        >
           {/* Stylized reflection line representing a car silhouette */}
           <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-brand-500 to-transparent shadow-[0_0_20px_rgba(14,165,233,0.5)]" />
           <div className="absolute bottom-0 left-1/4 right-1/4 h-32 bg-gradient-to-t from-brand-500/10 to-transparent blur-xl" />
        </motion.div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
         <div className="absolute top-1/3 left-10 w-2 h-2 bg-brand-400 rounded-full animate-float opacity-50" style={{ animationDelay: '0s' }} />
         <div className="absolute top-2/3 right-20 w-3 h-3 bg-brand-300 rounded-full animate-float opacity-30" style={{ animationDelay: '2s' }} />
         <div className="absolute bottom-1/4 left-1/3 w-1 h-1 bg-white rounded-full animate-float opacity-60" style={{ animationDelay: '4s' }} />
      </div>
    </section>
  );
};

export default Hero;