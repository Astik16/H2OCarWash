import React from 'react';
import Section from './ui/Section';
import Button from './ui/Button';
import { MapPin, Phone, Clock } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <Section id="contact" className="bg-dark-surface relative overflow-hidden">
       {/* Background glow */}
       <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-900/10 rounded-full blur-[100px] pointer-events-none" />

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
         {/* Contact Info & Form */}
         <div>
            <h2 className="text-4xl font-display font-bold text-white mb-8">Записаться <br/>на <span className="text-brand-500">Мойку</span></h2>
            
            <div className="space-y-6 mb-12">
               <div className="flex items-start gap-4">
                  <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                    <MapPin className="w-6 h-6 text-brand-400" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold mb-1">Адрес</h4>
                    <p className="text-gray-400">{BUSINESS_INFO.fullAddress}</p>
                  </div>
               </div>

               <div className="flex items-start gap-4">
                  <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                    <Phone className="w-6 h-6 text-brand-400" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold mb-1">Телефон</h4>
                    <a href={`tel:${BUSINESS_INFO.phone.replace(/[^\d+]/g, '')}`} className="text-gray-400 hover:text-white transition-colors">
                      {BUSINESS_INFO.phone}
                    </a>
                  </div>
               </div>

               <div className="flex items-start gap-4">
                  <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                    <Clock className="w-6 h-6 text-brand-400" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold mb-1">Режим работы</h4>
                    <p className="text-gray-400">Ежедневно с 9:00 до 21:00</p>
                  </div>
               </div>
            </div>

            <form className="space-y-4">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input 
                    type="text" 
                    placeholder="Ваше Имя" 
                    className="w-full bg-black/40 border border-white/10 rounded-sm px-4 py-3 text-white focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 transition-all placeholder:text-gray-600"
                  />
                  <input 
                    type="tel" 
                    placeholder="Телефон" 
                    className="w-full bg-black/40 border border-white/10 rounded-sm px-4 py-3 text-white focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 transition-all placeholder:text-gray-600"
                  />
               </div>
               <select className="w-full bg-black/40 border border-white/10 rounded-sm px-4 py-3 text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500 transition-all">
                  <option>Выберите услугу</option>
                  <option>Комплексная мойка</option>
                  <option>Химчистка</option>
                  <option>Полировка / Покрытия</option>
                  <option>Другое</option>
               </select>
               <Button className="w-full">Отправить заявку</Button>
               <p className="text-xs text-gray-500 text-center">
                 Нажимая кнопку, вы соглашаетесь с обработкой персональных данных.
               </p>
            </form>
         </div>

         {/* Map */}
         <div className="h-[500px] w-full rounded-2xl overflow-hidden border border-white/10 relative bg-gray-900">
           {/* Placeholder Map Overlay for visual consistency if iframe fails loading */}
           <div className="absolute inset-0 bg-gray-900 animate-pulse z-0"></div>
           
           <iframe 
             src="https://yandex.ru/map-widget/v1/?ll=44.062088%2C43.626880&mode=search&ol=geo&ouri=ymapsbm1%3A%2F%2Fgeo%3Fdata%3DCgg1NzMwOTMyNRJG0KDQvtGB0YHQuNGPLCDQmtCw0LHQsNGA0LTQuNC90L4t0JHQsNC70LrQsNGA0YHQutCw0Y8g0KDQtdGB0L_Rg9Cx0LvQuNC60LAsINCczCw0LnRgdC60LjQuSwg0YPQu9C40YbQsCDQk9C-0YDRjNC60L7Qs9C-LCAxMTgiCg0%2BCRVCFaN1QUA%2C&z=17" 
             width="100%" 
             height="100%" 
             frameBorder="0" 
             className="relative z-10 w-full h-full grayscale invert-[.9] contrast-125 opacity-80 hover:opacity-100 transition-opacity"
             title="Map location"
           ></iframe>
           
           {/* Custom Marker Overlay Styling (Simulated) */}
           <div className="absolute bottom-4 left-4 z-20 bg-dark-bg/90 p-4 rounded-lg backdrop-blur border border-white/10">
              <div className="font-bold text-white text-sm">H2O Car Wash</div>
              <div className="text-xs text-brand-400">ул. Горького, 118</div>
           </div>
         </div>
       </div>
    </Section>
  );
};

export default Contact;