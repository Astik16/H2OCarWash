import React from 'react';
import Section from './ui/Section';

const Gallery: React.FC = () => {
  return (
    <Section id="gallery">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-display font-bold text-white mb-4">Результат <span className="text-brand-500">Работы</span></h2>
        <p className="text-gray-400">Внимание к каждой детали.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-[400px] md:h-[500px]">
         {/* Placeholder for images. Since we use picsum, we simulate a premium look with overlays */}
         <div className="relative rounded-2xl overflow-hidden group border border-white/5">
            <img 
              src="https://picsum.photos/800/600?grayscale" 
              alt="Detailing Process" 
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-8">
               <h3 className="text-2xl font-bold text-white mb-2">Глубокая очистка</h3>
               <p className="text-gray-300">Удаление сложных загрязнений и битума</p>
            </div>
         </div>

         <div className="relative rounded-2xl overflow-hidden group border border-white/5">
            <img 
              src="https://picsum.photos/801/600" 
              alt="Detailing Result" 
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-8">
               <h3 className="text-2xl font-bold text-white mb-2">Зеркальный блеск</h3>
               <p className="text-gray-300">Полировка и нанесение защитных покрытий</p>
            </div>
         </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 border-t border-white/10 pt-10">
        <div className="text-center">
           <div className="text-4xl font-display font-bold text-brand-500 mb-2">5+</div>
           <div className="text-sm text-gray-400 uppercase tracking-wider">Лет опыта</div>
        </div>
        <div className="text-center">
           <div className="text-4xl font-display font-bold text-brand-500 mb-2">2k+</div>
           <div className="text-sm text-gray-400 uppercase tracking-wider">Довольных клиентов</div>
        </div>
        <div className="text-center">
           <div className="text-4xl font-display font-bold text-brand-500 mb-2">15</div>
           <div className="text-sm text-gray-400 uppercase tracking-wider">Видов услуг</div>
        </div>
        <div className="text-center">
           <div className="text-4xl font-display font-bold text-brand-500 mb-2">100%</div>
           <div className="text-sm text-gray-400 uppercase tracking-wider">Качество</div>
        </div>
      </div>
    </Section>
  );
};

export default Gallery;