import React from 'react';
import { Droplets } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-white/5 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          
          <div>
            <div className="flex items-center gap-2 mb-6">
              <Droplets className="w-6 h-6 text-brand-500" />
              <span className="text-xl font-display font-bold text-white">H2O <span className="text-brand-500 text-sm">Car Wash</span></span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
              Премиальная автомойка и детейлинг центр в Майском.
              Мы заботимся о вашем автомобиле так же, как вы.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Навигация</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#services" className="hover:text-brand-400 transition-colors">Услуги</a></li>
              <li><a href="#prices" className="hover:text-brand-400 transition-colors">Прайс-лист</a></li>
              <li><a href="#gallery" className="hover:text-brand-400 transition-colors">Примеры работ</a></li>
              <li><a href="#contact" className="hover:text-brand-400 transition-colors">Контакты</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Контакты</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li>{BUSINESS_INFO.fullAddress}</li>
              <li><a href={`tel:${BUSINESS_INFO.phone.replace(/[^\d+]/g, '')}`} className="hover:text-brand-400">{BUSINESS_INFO.phone}</a></li>
              <li>Ежедневно: 09:00 - 21:00</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-600 text-xs">
            © {new Date().getFullYear()} H2O Car Wash. Все права защищены.
          </p>
          <div className="flex gap-4">
             {/* Fake Socials */}
             <a href="#" className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-600 hover:text-white transition-all">VK</a>
             <a href="#" className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-600 hover:text-white transition-all">TG</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;