import React from 'react';
import Section from './ui/Section';
import { ADVANTAGES } from '../constants';
import { Star, Clock, CheckCircle, Shield } from 'lucide-react';

const Features: React.FC = () => {
  const icons = [Star, Clock, CheckCircle, Shield];

  return (
    <Section id="features" className="bg-dark-surface/50 border-y border-white/5">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-6">
            Почему выбирают <span className="text-brand-500">H2O</span>
          </h2>
          <p className="text-gray-400 text-lg mb-8 leading-relaxed">
            Мы не просто моем машины. Мы возвращаем им первозданный вид, используя технологии детейлинга, которые недоступны на обычных автомойках.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {ADVANTAGES.map((adv, index) => {
              const Icon = icons[index % icons.length];
              return (
                <div key={index} className="flex flex-col gap-3">
                  <div className="w-12 h-12 rounded-lg bg-brand-500/10 flex items-center justify-center border border-brand-500/20">
                    <Icon className="w-6 h-6 text-brand-400" />
                  </div>
                  <h4 className="text-xl font-bold text-white">{adv.title}</h4>
                  <p className="text-sm text-gray-400">{adv.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        <div className="relative h-[500px] w-full rounded-2xl overflow-hidden border border-white/10 group">
           {/* Abstract "Technology" Visual using CSS only */}
           <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black">
              {/* Animated scanning line */}
              <div className="absolute top-0 left-0 w-full h-1 bg-brand-500 shadow-[0_0_20px_rgba(14,165,233,1)] animate-[scan_4s_linear_infinite]" 
                   style={{ animationName: 'scan' }} 
              />
              <style>{`
                @keyframes scan {
                  0% { top: 0; opacity: 0; }
                  10% { opacity: 1; }
                  90% { opacity: 1; }
                  100% { top: 100%; opacity: 0; }
                }
              `}</style>
              
              {/* Grid representation */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(14,165,233,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(14,165,233,0.1)_1px,transparent_1px)] bg-[size:50px_50px]" />
              
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-8 bg-black/80 backdrop-blur-xl border border-brand-500/30 rounded-2xl max-w-sm">
                   <div className="text-6xl font-display font-bold text-brand-500 mb-2">100%</div>
                   <div className="text-xl text-white font-medium uppercase tracking-widest">Гарантия качества</div>
                   <div className="mt-4 text-sm text-gray-400">
                     Мы уверены в своей работе. Если вам не понравится результат — мы переделаем бесплатно.
                   </div>
                </div>
              </div>
           </div>
        </div>
      </div>
    </Section>
  );
};

export default Features;