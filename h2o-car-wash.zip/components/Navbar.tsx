import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Droplets } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Услуги', href: '#services' },
    { name: 'Преимущества', href: '#features' },
    { name: 'Галерея', href: '#gallery' },
    { name: 'Контакты', href: '#contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-dark-bg/90 backdrop-blur-md border-b border-white/5 py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="relative">
            <Droplets className="w-8 h-8 text-brand-500 group-hover:text-brand-400 transition-colors" />
            <div className="absolute inset-0 bg-brand-500/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-display font-bold tracking-widest text-white group-hover:text-glow transition-all">H2O</span>
            <span className="text-[10px] text-brand-400 tracking-[0.2em] uppercase">Car Wash</span>
          </div>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium text-gray-300 hover:text-brand-400 transition-colors uppercase tracking-wide"
            >
              {link.name}
            </a>
          ))}
          <a 
            href={`tel:${BUSINESS_INFO.phone.replace(/[^\d+]/g, '')}`}
            className="flex items-center gap-2 px-4 py-2 border border-brand-500/30 rounded-sm hover:border-brand-500 hover:bg-brand-500/10 transition-all"
          >
            <Phone className="w-4 h-4 text-brand-400" />
            <span className="text-sm font-bold text-white">{BUSINESS_INFO.phone}</span>
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-white hover:text-brand-400 transition-colors"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="absolute top-full left-0 w-full bg-dark-bg/95 backdrop-blur-xl border-b border-white/5 p-4 md:hidden flex flex-col gap-4 shadow-2xl">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="block p-4 text-center text-lg font-medium text-gray-200 hover:text-brand-400 hover:bg-white/5 rounded-sm uppercase tracking-wide"
              onClick={() => setIsOpen(false)}
            >
              {link.name}
            </a>
          ))}
          <a 
             href={`tel:${BUSINESS_INFO.phone.replace(/[^\d+]/g, '')}`}
             className="flex items-center justify-center gap-2 p-4 bg-brand-600 rounded-sm text-white font-bold"
          >
            <Phone className="w-5 h-5" />
            {BUSINESS_INFO.phone}
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;